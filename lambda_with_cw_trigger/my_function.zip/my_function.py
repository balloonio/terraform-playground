def my_integ_tester(event, context):
  message = "hello world!"
  return {"message": message}

